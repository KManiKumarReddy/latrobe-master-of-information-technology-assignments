public enum InvoiceStatus {
    issued, paid
}