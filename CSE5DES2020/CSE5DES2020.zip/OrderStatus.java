public enum OrderStatus {
    active, closed
}