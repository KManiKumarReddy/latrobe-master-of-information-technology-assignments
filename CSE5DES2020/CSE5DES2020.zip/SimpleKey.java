public interface SimpleKey
{
	public abstract String getKey();
}